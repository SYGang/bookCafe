package com.peisia.kiosk.book.product;

public class CouponDrink extends Product {
	

	public CouponDrink(String xx, int yy){
		super(xx,yy);
	}
	

}
