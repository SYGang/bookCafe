package com.peisia.kiosk.book.product;

public class Food extends Product{

	public Food(String xx, int yy) {
		super(xx,yy);
	}
	public String expiryDate;


}

