package com.peisia.kiosk.book.product;

public class Comic extends Product {
	

	public Comic(String xx, int yy){
		super(xx,yy);
	}
	

}
