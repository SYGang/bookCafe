package com.peisia.kiosk.book.product;

public class Novel extends Product{

	public Novel(String xx, int yy) {
		super(xx, yy);
		
	}

}
