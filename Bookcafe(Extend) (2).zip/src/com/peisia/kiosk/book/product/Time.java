package com.peisia.kiosk.book.product;

public class Time extends Product {
	
	
		public Time(String xx, int yy){
			super(xx,yy);
		}
		
	

	
}
