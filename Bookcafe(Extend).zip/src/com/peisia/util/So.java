package com.peisia.util;

public class So {

	public static void p(String s) {
		System.out.print(s);
	}
	public static void ln(int i) {
		System.out.println(i);
	}		
		public static void ln(String s) {
			System.out.println(s);
			
	}
	public static void ln() {
		System.out.println();
	}
}
